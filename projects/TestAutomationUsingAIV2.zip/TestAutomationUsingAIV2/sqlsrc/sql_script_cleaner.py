class SqlScriptCleaner:
    @staticmethod
    def get_clean_sql_script(script_content):
        pass
