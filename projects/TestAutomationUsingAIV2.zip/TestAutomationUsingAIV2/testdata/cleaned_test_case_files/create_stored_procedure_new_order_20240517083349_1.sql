
-- Start by creating a test class for the uspPlaceNewOrder stored procedure
EXEC tSQLt.NewTestClass 'TestSales.uspPlaceNewOrder';

-- Now we can create a test method to test the behavior of the uspPlaceNewOrder procedure
CREATE PROCEDURE TestSales.uspPlaceNewOrder_Test
AS
BEGIN
    -- As the procedure is inserting data into the Orders and updating Customer table, we need to use a separate test schema
    EXEC tSQLt.FakeTable 'Sales.Orders';
    EXEC tSQLt.FakeTable 'Sales.Customer';

    -- Insert some test data into the Customer table for testing
    INSERT INTO Sales.Customer (CustomerID, YTDOrders)
    VALUES (1, 100);

    -- Execute the uspPlaceNewOrder procedure
    DECLARE @RC INT;
    EXEC @RC = Sales.uspPlaceNewOrder @CustomerID = 1, @Amount = 50, @OrderDate = '2021-01-01', @Status = 'O';

    -- Check if the procedure returned a valid identity value
    EXEC tSQLt.AssertEquals @Expected = 1, @Actual = @RC;

    -- Check if the Orders table was inserted with the correct data
    DECLARE @OrderCount INT;
    SELECT @OrderCount = COUNT(*) FROM Sales.Orders;
    EXEC tSQLt.AssertEquals @Expected = 1, @Actual = @OrderCount;

    -- Check if the Customer table was updated correctly
    DECLARE @YTDOrders INT;
    SELECT @YTDOrders = YTDOrders FROM Sales.Customer WHERE CustomerID = 1;
    EXEC tSQLt.AssertEquals @Expected = 150, @Actual = @YTDOrders;
END;
