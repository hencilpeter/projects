-- Unit test for inserting data into the Customer table
-- Test scenario: Inserting a new customer record

-- 1. Arrange
DECLARE @CustomerName NVARCHAR(40) = 'John Doe';
DECLARE @YTDOrders INT = 10;
DECLARE @YTDSales INT = 1000;

-- 2. Act
INSERT INTO [Sales].[Customer] ([CustomerName], [YTDOrders], [YTDSales])
VALUES (@CustomerName, @YTDOrders, @YTDSales);

-- 3. Assert
SELECT * FROM [Sales].[Customer] WHERE [CustomerName] = @CustomerName;