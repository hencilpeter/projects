To write a unit test for the SQL Server script provided, we will be using SQL Server's built-in testing framework called tSQLt. tSQLt allows us to create unit tests for database objects like stored procedures, functions, triggers, etc. Below is an example of how we can write a unit test for the [Sales].[uspPlaceNewOrder] procedure:

```sql
-- Start by creating a test class for the uspPlaceNewOrder stored procedure
EXEC tSQLt.NewTestClass 'TestSales.uspPlaceNewOrder';

-- Now we can create a test method to test the behavior of the uspPlaceNewOrder procedure
CREATE PROCEDURE TestSales.uspPlaceNewOrder_Test
AS
BEGIN
    -- As the procedure is inserting data into the Orders and updating Customer table, we need to use a separate test schema
    EXEC tSQLt.FakeTable 'Sales.Orders';
    EXEC tSQLt.FakeTable 'Sales.Customer';

    -- Insert some test data into the Customer table for testing
    INSERT INTO Sales.Customer (CustomerID, YTDOrders)
    VALUES (1, 100);

    -- Execute the uspPlaceNewOrder procedure
    DECLARE @RC INT;
    EXEC @RC = Sales.uspPlaceNewOrder @CustomerID = 1, @Amount = 50, @OrderDate = '2021-01-01', @Status = 'O';

    -- Check if the procedure returned a valid identity value
    EXEC tSQLt.AssertEquals @Expected = 1, @Actual = @RC;

    -- Check if the Orders table was inserted with the correct data
    DECLARE @OrderCount INT;
    SELECT @OrderCount = COUNT(*) FROM Sales.Orders;
    EXEC tSQLt.AssertEquals @Expected = 1, @Actual = @OrderCount;

    -- Check if the Customer table was updated correctly
    DECLARE @YTDOrders INT;
    SELECT @YTDOrders = YTDOrders FROM Sales.Customer WHERE CustomerID = 1;
    EXEC tSQLt.AssertEquals @Expected = 150, @Actual = @YTDOrders;
END;
```

In the above example, we first create a test class for the [Sales].[uspPlaceNewOrder] procedure using `tSQLt.NewTestClass`, then create a test method `uspPlaceNewOrder_Test` to test the behavior of the procedure. We use `tSQLt.FakeTable` to fake the tables before execution to isolate the test. We then insert test data into the Customer table, execute the stored procedure, and validate the results using `tSQLt.AssertEquals`.

To run the test, we simply execute the test method:

```sql
EXEC tSQLt.Run 'TestSales.uspPlaceNewOrder_Test';
```

This will run the unit test and provide the results. If all assertions pass, the test is successful.