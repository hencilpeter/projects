-- create table test
CREATE TABLE [Sales].[Customer_Test] (
    [CustomerID]   INT           IDENTITY (1, 1) NOT NULL,
    [CustomerName] NVARCHAR (40) NOT NULL,
    [YTDOrders]    INT           NOT NULL,
    [YTDSales]     INT           NOT NULL
);

-- insert test data
INSERT INTO [Sales].[Customer_Test] ([CustomerName], [YTDOrders], [YTDSales])
VALUES ('John Doe', 10, 1000),
       ('Jane Smith', 5, 500);

-- Assert table has been created
IF OBJECT_ID('[Sales].[Customer_Test]') IS NOT NULL
BEGIN
    PRINT 'Table [Sales].[Customer_Test] has been created successfully';
END
ELSE
BEGIN
    PRINT 'Table [Sales].[Customer_Test] creation failed';
END

-- Assert data has been inserted
DECLARE @Count INT;
SELECT @Count = COUNT(*)
FROM [Sales].[Customer_Test]

IF @Count = 2
BEGIN
    PRINT 'Data has been inserted successfully';
END
ELSE
BEGIN
    PRINT 'Data insertion failed';
END

-- clean up test table
DROP TABLE [Sales].[Customer_Test];