EXEC tSQLt.NewTestClass 'test_uspPlaceNewOrder';
GO

CREATE PROCEDURE test_uspPlaceNewOrder.[test Order is placed successfully]
AS
BEGIN
    -- Arrange
    DECLARE @CustomerID INT = 1;
    DECLARE @Amount INT = 100;
    DECLARE @OrderDate DATETIME = GETDATE();
    
    -- Act
    DECLARE @OrderId INT;
    EXEC @OrderId = [Sales].[uspPlaceNewOrder] @CustomerID, @Amount, @OrderDate;
    
    -- Assert
    DECLARE @ExpectedOrderId INT;
    SELECT @ExpectedOrderId = MAX(OrderID) FROM [Sales].[Orders] WHERE CustomerID = @CustomerID;
    
    EXEC tSQLt.AssertEquals @Expected = @ExpectedOrderId, @Actual = @OrderId, @Message = 'Order ID mismatch';
    
    -- Additional Assert for updating YTDOrders in [Sales].[Customer] table
    DECLARE @ExpectedYTDOrders INT;
    SELECT @ExpectedYTDOrders = SUM(Amount) FROM [Sales].[Orders] WHERE CustomerID = @CustomerID;
    
    DECLARE @ActualYTDOrders INT;
    SELECT @ActualYTDOrders = YTDOrders FROM [Sales].[Customer] WHERE CustomerID = @CustomerID;
    
    EXEC tSQLt.AssertEquals @Expected = @ExpectedYTDOrders, @Actual = @ActualYTDOrders, @Message = 'YTDOrders mismatch';
END

EXEC tSQLt.Run 'test_uspPlaceNewOrder';
GO