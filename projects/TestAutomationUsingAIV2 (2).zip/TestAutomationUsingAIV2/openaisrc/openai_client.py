from openai import OpenAI


class OpenAIClient:
    @staticmethod
    def get_openai_client():

        return client
